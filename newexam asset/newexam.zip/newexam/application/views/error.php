<div class="jumbotron">
    <h2><? echo $title; ?></h2>
    <? echo $msg;?>
    <p><a class="btn btn-primary btn-lg" href="#" role="button" onclick="window.close()">关闭</a></p>
</div>