<?php
class WXApi {
	function __construct() {
	}
}
?>
