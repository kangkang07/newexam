<?php
class FileHelper {
	function __construct() {
		$this->CI=&get_instance();
	}
	protected $CI;
	public function uploadimg($imgfield)
	{
	}
}
?>
