<?php
/*
 * 验证码
 */
class CaptchaHelper {
	function __construct() {
	}
}
?>
