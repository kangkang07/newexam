<?php
class WBApi {
	function __construct() {
	}
}
?>
