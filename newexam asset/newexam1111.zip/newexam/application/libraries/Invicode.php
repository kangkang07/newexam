<?php
class Invicode {
	function __construct() {
	}
	
	
	private $regtable;
	private 
	
}

?>