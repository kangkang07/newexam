
$(document).ready(function(){
    
});
function search()
{
	
    $.ajax({
       "url":"/search",
        "data":{
            
        },
        "success":function(data){
            
        }
    });
}
