<?php

class QQApi {
	function __construct() {
	}
}
?>
