<?php
class TagLogicAPI extends ET_Controller {
	public function __construct() {
		parent::__construct ();
	}
}

?>