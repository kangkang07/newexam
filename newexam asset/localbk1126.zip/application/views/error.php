<div class="jumbotron">
    <h2><? echo $title; ?></h2>
    <? echo $msg;?>

</div>