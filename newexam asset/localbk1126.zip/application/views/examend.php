<div class="jumbotron">
    <h2>考试已经结束。请关闭页面。</h2>
    
<!--    <p><a class="btn btn-primary btn-lg" href="#" role="button" onclick="window.open('','_self').close()">关闭</a></p>-->
</div>